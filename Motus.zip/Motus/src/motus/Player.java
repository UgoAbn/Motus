/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motus;

import java.io.*;
import java.util.*;

/**
 *
 * @author Ugo
 */
public class Player {
    Player playerConnected;
    String surname;
    String name;
    String nametag;
    String password;
    LinkedList listeScore;

    public Player(String surname, String name, String nametag, String password) {
        this.surname = surname;
        this.name = name;
        this.nametag = nametag;
        this.password = password;
        this.listeScore = new LinkedList<Integer>();
    }

    @Override
    public String toString() {
        return "Player{" + "surname=" + surname + ", name=" + name + ", nametag=" + nametag + ", password=" + password + ", listeScore=" + listeScore + '}';
    }
    
    //Getter 

    public String getNametag() {
        return nametag;
    }
    
    //towardFile function
    public String towardFile() {
        return surname + " : " + name + " : " + nametag + " : " + password + System.lineSeparator();
    }
    
    
    
    
}
