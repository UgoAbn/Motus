/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motus;

import java.io.*;
import java.util.*;

/**
 *
 * @author Ugo
 */
public class Motus {

    /**
     * @param args the command line arguments
     */
    
    private LinkedList PlayerList;
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Words ensemble = new Words();
        ensemble.chargementFichierMots();
        ensemble.sauvegardeFichierMots();
        
    }
    
}
