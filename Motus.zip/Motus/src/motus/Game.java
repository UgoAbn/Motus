/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motus;

import java.io.*;
import java.util.*;

/**
 *
 * @author Ugo
 */
public class Game {
    private String choosedWord;
    private LinkedList<String> listWords;
    private LinkedList<Player> listPlayers;
    
    /*
    Attributs for folders
    */
    String folderPlayers = "folderPlayer";
    private String folderWords = "folderWords";

    public Game(LinkedList<String> listWords) {
        this.listWords = listWords;
    }
    
    /*
    Functions to load and save folders
    */
    
    public void loadPlayersFolder() throws FileNotFoundException, IOException {
        FileReader fich = new FileReader(folderPlayers);
        BufferedReader br = new BufferedReader(fich);
        String ref = br.readLine();
        try {
            while (ref != null) {
                String tab[] = ref.split(" : ");
                String surname = tab[0];
                String name = tab[1];
                String nametag = tab[2];
                String password = tab[3];
                listPlayers.add(new Player(surname, name, nametag, password));
                ref = br.readLine();
            }
            fich.close();
        }
        catch (Exception ex) {
            System.out.println("Error");
        }
    }
    
    public void savePlayersFolder() {
        try {
            FileWriter fich = new FileWriter(folderPlayers);
            Iterator<Player> it = listPlayers.iterator();
            while(it.hasNext()) {
                fich.write(it.next().towardFile() + System.lineSeparator());
            }
        fich.close();
        }
        catch (Exception ex) {
            System.out.println("Error");
        }
    }
    
    public void loadWordsFolder() throws FileNotFoundException, IOException {
        FileReader fich = new FileReader(folderWords);
        BufferedReader br = new BufferedReader(fich);
        String ref = br.readLine();
        try {
            while (ref != null) {
                String word = ref;
                listWords.add(word);
                ref = br.readLine();
            }
            fich.close();
        }
        catch (Exception ex) {
            System.out.println("Error");
        }
    }

    public void saveWordsFolder() {
        try {
            FileWriter fich = new FileWriter(folderWords);
            Iterator<String> it = listWords.iterator();
            while(it.hasNext()) {
                fich.write(it.next() + System.lineSeparator());
            }
        fich.close();
        }
        catch (Exception ex) {
            System.out.println("Error");
        }
    }
    
    /*
    User functions
    */
    
    public void addUser(String surname, String name, String nametag, String password) {
        listPlayers.add(new Player(surname, name, nametag, password));
    }
    
    public void Login(String nametag, String password) {
        Iterator<Player> it = listPlayers.iterator();
    }
    
    /*
    Words functions
    */
    
    public void chooseRandomWord() {
        Random rand = new Random(listWords.size());
        try {
            int randomNumber = rand.nextInt();
            listWords.get(randomNumber);
        } catch (Exception ex) {
            System.out.println("Error");
        }
    }
    
    public void checkEqualsWord(String givenWord, String searchedWord) {
        int redBox = 0;
        if (givenWord.equals(searchedWord)) {
            
        }
    }
    
    /*
    Gameboard functions
    */
    
    
}
