/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motus;

import java.io.*;
import java.util.*;

/**
 *
 * @author Ugo
 */


public class Words {
    
    private LinkedList<String> listWords;
    LinkedList<String> listSort;

    public Words() {
        this.listWords = new LinkedList<String>();
        this.listSort = new LinkedList<String>();
    }
    
    public void deleteWord() {
        Iterator<String> it = listSort.iterator();
        int cpt = 0;
        while (it.hasNext()) {
            System.out.println("Hehe " + cpt++);
            listWords.remove(it.next());
        }
            
    }
    
    public void triMots() {
        int cpt = 0;
        Iterator<String> it = listWords.iterator();
        while(it.hasNext()) {
            String word = it.next();
            System.out.println("tata " + cpt++);
            if (word.length() < 5 || word.length() > 9) {
                listSort.add(word);
            }    
        }
    }
}
