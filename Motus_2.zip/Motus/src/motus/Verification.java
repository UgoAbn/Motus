/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package motus;

/**
 *
 * @author Ugo
 */
public class Verification {
    String choosedWord;
    String wordToVerified;

    public Verification(String choosedWord, String wordToVerified) {
        this.choosedWord = choosedWord;
        this.wordToVerified = wordToVerified;
    }
    
    
    
    public void checkEqualsWord() {
        int redBox = 0;
        int i;
        for (i = 0; i < choosedWord.length(); i++) {
            if (compare(choosedWord.charAt(i),wordToVerified.charAt(i))) {
                
            }
        }
    }
}
